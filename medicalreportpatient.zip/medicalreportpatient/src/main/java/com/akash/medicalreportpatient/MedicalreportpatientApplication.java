package com.akash.medicalreportpatient;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class MedicalreportpatientApplication {

	public static void main(String[] args) {
		SpringApplication.run(MedicalreportpatientApplication.class, args);
	}

}
